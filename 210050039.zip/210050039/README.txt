Chaitanya Garg 210050039

In this project, I have implimented the following features:
1) Gravity to incorporate vertical motion of the bubbles so that they now move in parabolic paths.
2) Bubbles bounce on ground.
3) Collision between bubble and bullet, as a result of which, when they collide, both disappear and score increases.
4) Collision between bubble and shooter, as a result of which, when they collide, health decreases, and the shooter turns cyan for the duration of collision.
5) A score counter. Score increase when you hit a bubble.
6) A timer and a health counter.
7) When too low, timer and health counter turn red. (when timer<10sec, it turns red and when health <=1, it turns red). When any of these turn 0, game ends. Timer resets at each level, but health does not.
8) 3 Levels. On succeeding levels, the bubbles become larger, faster, more in number and of different color. The gravity becomes stronger. Instead of the bubble dying imidiately when bullet hits it, it breaks into 2 bubbles of half the radius, until a threashold radius.
9) Addded controls for arrow keys as well, along with the already given w-a-d controls.

Link to Gameplay Video: https://drive.google.com/drive/folders/1RThNf8Qylbkz8tiOPR39PbyB0lRpQG3W?usp=sharing